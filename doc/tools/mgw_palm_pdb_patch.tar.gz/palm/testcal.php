<?php
    //Tell the groupware we are in calendar mode
    $myEnv[module] = "calendar";
	$myEnv[output] = "html";

	include("../config.inc.php");
	include("../include/container.inc");
    
    //Include the php-pdb stuff
    ini_set('error_reporting', E_ALL);
    include "./php-pdb.inc";
    include "./modules/datebook.inc";
    include "./modules/doc.inc";
    $pdb = new PalmDatebook();
    
    //Change debug to 1 if you want to see the output
    $pdb_debug = 0;
    
    // Get all entries for a user
    if(!isset($action)) 
	{	
		if (!session_is_registered('calendarid'))
		{  
			$sql = "SELECT CONCAT(lastname, ', ', firstname) AS name
						FROM mgw_users
						WHERE id = $MGW->userid";
			if(!$res = $conn->Execute($sql)) die(showSQLerror2($sql, __LINE__));
			$row = $res->GetRowAssoc(false);
			$calendarid	 = $MGW->userid;
			$calendarname = $row[name];
			session_register('calendarid');
			session_register('calendarname');
		}
  	
  	
  		// select owner
  		$sql = "SELECT id, CONCAT(lastname, ', ', firstname) AS name
					FROM mgw_users
					ORDER BY 2";

		if(!$res = $conn->Execute($sql)) die(showSQLerror2($sql, __LINE__));		
        
        $sql = "SELECT *
				FROM mgw_calendar 
				WHERE userid = $calendarid";
        $result = mysql_query($sql);
                  
        while($row = mysql_fetch_object($result)) 
        {
            
            $startdate =  $row->date;
            $pdb_description = $row->subject;
            $pdb_date = substr($startdate,0,4) ."-" .substr($startdate,4,2) ."-". substr($startdate,6,2);
            $pdb_start_time = substr($startdate,8,4);
            
            $duration = $row->duration;             
            
            $pdb_end_time = substr($pdb_start_time,0,2) * 60;
            $pdb_end_time = $pdb_end_time + substr($pdb_start_time,2,2);
            $pdb_end_time = $pdb_end_time + $duration;
            $pdb_end_time = $pdb_end_time/60;
            if (strchr($pdb_end_time,"."))
            {
                list ($hour, $mins) = split('[/.-]', $pdb_end_time);
            }else{
                $hour = $pdb_end_time;
            }
            if (isset($mins))
            {
                $mins = 30;
            }else{
                $mins = 00;
            }

            $pdb_start_time = substr($pdb_start_time,0,2) .":" . substr($pdb_start_time,2,2);
            $pdb_end_time = $hour . ":" . $mins;
            
            $dow = date("w",$pdb_date);
            
            if ($pdb_debug == 1){
                
                print "I am user ID : $calendarid<BR>";
                print "Subject is : $pdb_description<BR>";
                print "Calendar start date is : $startdate<BR>";
                print "Palm start date is : $pdb_date<BR>";
                print "Palm start time is : $pdb_start_time<BR>";
                print "Appointment duration is : $duration<BR>";
                print "Palm end time in minutes : $pdb_end_time<BR>";
                print "Day of week is : $dow<BR>";
                print "Repeat or not (0 or 1) : $row->repeat<BR>";
                print "<HR>";
            }    
            $Record = array(
                "StartTime" => $pdb_start_time,
                "EndTime" => $pdb_end_time,
                "Date" => $pdb_date,
                "Description" => "$pdb_description"
            );
                               
            // Add the record to the datebook
            $pdb->SetRecordRaw($Record);

            // Advance to the next record just in case we want to add more events
            $pdb->GoToRecord("+1");                      
        }
    }
    
// Writing to a file
$fp = fopen("output_file.pdb", "wb");
if (! $fp) exit;  // There was an error opening the file
$pdb->WriteToFile($fp);
fclose($fp);
        
if ($pdb_debug == 1)
{
    // Writing to standard output
    $pdb->WriteToStdout();
}else{
    // Download through browser
    $pdb->DownloadPDB("DatebookDB.pdb");
}
?>
