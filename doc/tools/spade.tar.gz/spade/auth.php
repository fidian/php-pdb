<?

if (($PHP_AUTH_USER != "user") || ($PHP_AUTH_PW != "pwd"))
{
  header("WWW-Authenticate: Basic realm=\"palm data\"");
  header("HTTP/1.0 401 Unauthorized");
  echo "<p>not authorized.</p>\n";
  exit;
}

?>

